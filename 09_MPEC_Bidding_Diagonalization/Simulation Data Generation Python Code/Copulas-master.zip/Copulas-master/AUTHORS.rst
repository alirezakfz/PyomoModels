Credits
=======

* Manuel Alvarez <manuel@pythiac.com>
* Carles Sala <carles@pythiac.com>
* (Alicia)Yi Sun <yis@mit.edu>
* José David Pérez <jose@pythiac.com>
* Kevin Alex Zhang <kevz@mit.edu>
* Andrew Montanez <amontane@mit.edu>
* Kalyan Veeramachaneni <kalyan@csail.mit.edu>
* paulolimac <paulolimac@gmail.com>
* Gabriele Bonomi <gbonomib@gmail.com>
