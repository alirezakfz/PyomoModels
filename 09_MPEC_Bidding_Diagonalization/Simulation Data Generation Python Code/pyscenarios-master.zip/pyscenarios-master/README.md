pyscenarios
===========
Python Monte Carlo Scenario Generator

Full documentation at http://pyscenarios.readthedocs.io/

[![docs-badge](https://github.com/crusaderky/pyscenarios/workflows/Documentation/badge.svg)](https://github.com/crusaderky/pyscenarios/actions)
[![lint-badge](https://github.com/crusaderky/pyscenarios/workflows/Lint/badge.svg)](https://github.com/crusaderky/pyscenarios/actions)
[![pytest-badge](https://github.com/crusaderky/pyscenarios/workflows/Test%20latest/badge.svg)](https://github.com/crusaderky/pyscenarios/actions)
[![pytest-minimal-badge](https://github.com/crusaderky/pyscenarios/workflows/Test%20minimal/badge.svg)](https://github.com/crusaderky/pyscenarios/actions)
[![pytest-nojit-badge](https://github.com/crusaderky/pyscenarios/workflows/Test%20without%20JIT/badge.svg)](https://github.com/crusaderky/pyscenarios/actions)
[![codecov-badge](https://codecov.io/gh/crusaderky/pyscenarios/branch/master/graph/badge.svg)](https://codecov.io/gh/crusaderky/pyscenarios/branch/master)
